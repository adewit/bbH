#!/bin/csh

set echo

  mv pythiaExampleRead.lpt pythiaExampleRead.lpt.bak
  mv pythiaExampleRead.io  pythiaExampleRead.io.bak
  mv pythiaExampleReadBack.lpt pythiaExampleReadBack.lpt.bak
 ./pythiaExampleRead
